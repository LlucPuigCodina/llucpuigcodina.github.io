function [BDrawInt] = dyadicSQBbridge(T, tN, x, z, mu, N, grid, BDraw, iL, iR)
% Recursive implementation of dyadic sampling of a standard Squared Bessel
% bridge or order mu at time grid points tN with starting value X_0 = x and
% X_T = z. mu = delta/2 - 1.

%By Lluc Puig Codina

    if nargin == 5 % first call.
        grid  = [0; tN; T];
        N     = numel(grid);
        BDraw = NaN(N, 1);
    
        BDraw(1) = x;   BDraw(N) = z;
    
        BDraw    = dyadicSQBbridge(T, tN, x, z, mu, N, grid, BDraw, 1, N);
        BDrawInt = BDraw(2:end-1); % Only interior points of the bridge.
        return
    end
    
    if iR - iL <= 1 % stop recursion when there is no more to fill.
        BDrawInt = BDraw;
        return
    end
    
    iM = floor((iL + iR)/2); % mid point.    
    
    if isnan(BDraw(iM))
    
            tL = grid(iL); xL = BDraw(iL);
            tR = grid(iR); xR = BDraw(iR);
            tM = grid(iM);
    
            BDraw(iM) = sampleSQBbridge(tR-tL, tM-tL, xL, xR, mu);
    end

    % recursive left
    BDraw = dyadicSQBbridge(T, tN, x, z, mu, N, grid, BDraw, iL, iM); 
    % recursive right
    BDraw = dyadicSQBbridge(T, tN, x, z, mu, N, grid, BDraw, iM, iR);

    BDrawInt = BDraw;
end