function [XDraw] = sampleSQBbridge(T, t, x, z, mu)
% Exact sampling of X_t from a standard Squared Bessel Bridge process of 
% order mu with initial condition X_t1 = x at, without loss of generality, 
% t1 = 0 and X_t2 = z, t2 = T. Based on Makarov, R. N., & Glew, D. (2010). 
% "Exact simulation of Bessel diffusions." Monte Carlo Methods and 
% Applications, 16(3–4), 283–306. https://doi.org/10.1515/mcma.2010.010

% By Lluc Puig Codina

Y = poissrnd(((T-t)*x/t + t*z/(T-t))/(2*T)); 
Z = besselrndDevroye(mu, sqrt(x*z)/T);
XDraw = gamrnd(Y + 2*Z + mu + 1, (2*t*(T-t))/T); %shape/scale param.
