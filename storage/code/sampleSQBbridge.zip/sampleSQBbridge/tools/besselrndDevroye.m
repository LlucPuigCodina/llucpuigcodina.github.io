function [X] = besselrndDevroye(nu, a)
% Exact sampling of the Bessel distribution with parameters a and nu.
% Implementation of Algorithm 1 in L. Devroye, "Simulating Bessel random 
% variables," Statistics and Probability Letters, vol. 57, pp. 249-257, 
% 2002.
% by Lluc Puig Codina.

    if a == 0 % Degenerate random variable, constant at 0.
        X = 0;
        return;
    end

% Algorithm 1 requiring the computation of first type of modified Bessel
% function and the Gamma function. Expected number of iterations = 4 + pm.
    
    m   = floor((sqrt(a^2 + nu^2) -nu)/2);
    
    % Constants involved in log(p_m+X) - log(p_m)
    c1 = 2*log(a/2); c2 = gammaln(m+1); c3 = gammaln(m+nu+1);
    
    pm = exp((m + nu/2)*c1 - log(besseli(nu,a,1)) - a - c2 - c3);
    
    w  = 1 + pm/2;

    % Random Variable Generation
    while true
        
        U = rand(1);
        W = rand(1);
        S = (rand(1) > 0.5)*2 - 1; % Random sign

        if U <= w/(1+w)
            Y = rand(1)*w/pm;
        else
            Y = (w + exprnd(1))/pm;
        end

        X = S*round(Y);

        % Are we done?
        if (W*min(1, exp(w-pm*Y))) <= r(X, nu, m, c1, c2, c3)
            X = X + m;
            return
        end
    end
end

%% Auxiliary functions
function f = r(x, nu, m, c1, c2, c3)
    if x + m < 0
        f = -1;
    else
        f = x*c1 - gammaln(m + x + 1) + c2 - gammaln(m + x + nu + 1) + c3;
        f = exp(f);
    end
end

