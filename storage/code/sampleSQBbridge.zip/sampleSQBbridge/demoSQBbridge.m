% Simulate and plot a Squared Bessel bridge.

% by Lluc Puig Codina. 

%% housekeeping
clearvars; close all; clc;

%% add tools to path
addpath('tools');

%% Fix the seed
seed=555;  
rng(seed);
nSim = 5;

%% Simulate Squared Bessel bridge
X0 = 10; XT = 2; T = 3; delta = 3; inc = 0.005;

range     = (inc:inc:(T-inc))';
time      = [0; range; T];
bridge    = NaN(numel(time), nSim);

for i = 1:nSim 
    midpoints   = dyadicSQBbridge(T, range, X0, XT, (delta/2)-1);
    bridge(:,i) = [X0; midpoints; XT];
end

%% Plot
styles = {'-', '--', ':', '-.', '*-'};

hold on
for i = 1:nSim
    plot(time, bridge(:,i), ['k' styles{i}], 'LineWidth', 1);
end
plot([0;T], [X0; XT], 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r');
hold off

titleStr = sprintf(['Squared Bessel Bridge \n $\\delta$ = %.2f; $T$ ' ...
    '= %.2f; $\\Delta$ = %.2f; ' ...
    '$X_0$ = %.2f; $X_T$ = %.2f'], delta, T, inc, X0, XT);
title(titleStr, 'Interpreter', 'latex');
