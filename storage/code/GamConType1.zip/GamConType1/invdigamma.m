function [x, k] = invdigamma(y)
% Inverse Digamma function. y must be a real scalar.
% by Lluc Puig Codina.

    % Employ Newton-Rhapson with initial value based on the Necdet 
    % Batir bounds

    %Setup
    tol = 1e-14; 
    maxit = 20; 

    % Initial Value based on the bounds by Necdet Batir
    xmin = realmin("double");
    L    = max(xmin, 1 ./ log1p(exp(-y)));        % lower bound
    U    = max(L+xmin, exp(y) + 0.5);             % upper bound

    psiL = psi(L);      psiU = psi(U);       
    x = max(xmin, L + (y - psiL) .* (U - L) ./ (psiU - psiL));

    %Newton–Raphson
    for k = 1:maxit    
        
        fy  = psi(x) - y;
        dfx = psi(1, x); 
        delta = fy ./ dfx;
        xn   = max(xmin, x - delta);
    
        outL = xn < L; outU = xn > U; %Check if outside of bracket
        xn(outL | outU) = 0.5*(L(outL|outU) + U(outL|outU));
    
        fnew = psi(xn) - y; %Update bracket by monotonicity of psi
        goLeft  = fnew > 0;   
        U(goLeft) = xn(goLeft);
        L(~goLeft) = xn(~goLeft);
        
        if all(abs(fnew) < tol) % Evaluate wether to stop
            break; 
        end
        x = xn;
    end

    if (k == maxit) && (abs(fnew) >= tol || isnan(fnew))
        warning("Newton–Raphson has not converged."); 
    end
end
