function [x, k] = invdigamma(y)
% Inverse Digamma function. y must be a real scalar.
% by Lluc Puig Codina.

    % Employ Newton-Raphson with initial value based on the Necdet
    % Batir bounds

    %Setup
    tol   = 1e-14;
    maxit = 120;

    % Effective tolerance: for large |y|, the floating-point precision
    % of psi(x) is ~|y|*eps, making abs(fnew)<1e-14 unachievable.
    % Use a mixed absolute/relative criterion.
    tol_eff = max(tol, abs(y) * 1e-12);

    % Initial Value based on the bounds by Necdet Batir
    xmin = realmin("double");
    L    = max(xmin, 1 ./ log1p(exp(-y)));        % lower bound
    U    = max(L+xmin, exp(y) + 0.5);             % upper bound

    % For y << -1 the bracket (L,U) is very wide and the linear
    % interpolation gives a poor starting point.  Use the asymptotic
    % approximation psi(x) ~ -1/x - gamma  =>  x* ~ 1/(-y + gamma).
    if y < -1
        x = max(xmin, 1 / (-y + 0.5772156649));
    else
        psiL = psi(L);  psiU = psi(U);
        x = max(xmin, L + (y - psiL) .* (U - L) ./ (psiU - psiL));
    end

    %Newton-Raphson
    for k = 1:maxit

        fy  = psi(x) - y;
        dfx = psi(1, x);
        delta = fy ./ dfx;
        xn   = max(xmin, x - delta);

        outL = xn < L; outU = xn > U; %Check if outside of bracket
        xn(outL | outU) = 0.5*(L(outL|outU) + U(outL|outU));

        fnew = psi(xn) - y; %Update bracket by monotonicity of psi
        goLeft  = fnew > 0;
        U(goLeft) = xn(goLeft);
        L(~goLeft) = xn(~goLeft);

        x = xn;
        
        if all(abs(fnew) < tol_eff) % Evaluate whether to stop
            break;
        end
    end

    if (k == maxit) && (abs(fnew) >= tol_eff || isnan(fnew))
        warning("Newton-Raphson has not converged.");
    end
end
