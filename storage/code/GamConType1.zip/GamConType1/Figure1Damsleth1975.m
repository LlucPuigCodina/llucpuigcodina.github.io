% Reproduction of Figure 1 by Monte-Carlo in Damsleth, E. Conjugate Classes
% for Gamma Distributions, Scand J Statist 2: 80-84, 1975.

% By Lluc Puig Codina

% Monte-Carlo
size = 10^6;

n5  = sampleGamConType1(6.05, 5,  size);
n10 = sampleGamConType1(5.01, 10, size);
n30 = sampleGamConType1(4.26, 30, size);

% Figure 1
X = {n5, n10, n30};  

names = {'n = 5','n = 10','n = 30'};
style = {'k-.', 'k--', 'k-'};

xi = linspace(min(cellfun(@min,X)), max(cellfun(@max,X)), 500);

figure; hold on;
for i = 1:numel(X)
    f = ksdensity(X{i}, xi);
    plot(xi, f, style{i}, 'LineWidth', 2);
end
grid on;

legend(names, 'Location', 'best');
xlabel('x'); ylabel('Density');
title('Fig. 1. Posterior distributions for a from example 2.4.');



