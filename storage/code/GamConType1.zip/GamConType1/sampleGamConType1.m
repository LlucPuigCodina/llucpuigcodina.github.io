function [S] = sampleGamConType1(mu, delta, n)
% Sampling of the GamCon Type 1 distribution of Damsleth, E. Conjugate
% Classes for Gamma Distributions, Scand J Statist 2: 80-84, 1975.
%
% Implementation based on the algorithm of Devroye, L. Random variate
% generation for the generalized inverse Gaussian distribution. Stat Comput
% 24, 239-246, 2014.
%
% By Lluc Puig Codina

   %Preallocate
   S = NaN(n,1);

   % Mode
    logmu = log(mu);
    m = invdigamma(logmu);

   % Candidates t and s
    t = findT(1, m, logmu, delta);
    s = findS(min(t,m-0.5), m, logmu, delta);
    
   % Algorithm with three piece hat
    % Calculate [-psi(t), -dpsi(t), -psi(-s), dpsi(-s)]
    eta      = -psiD(t, m, logmu, delta);
    zeta     = -dpsiD(t, m, logmu, delta);
    theta    = -psiD(-s, m, logmu, delta);
    xi       = dpsiD(-s, m, logmu, delta);

    % Compute p, r, td, sd and q
    p    = 1./xi;
    r    = 1./zeta;
    td   = t - r*eta;
    sd   = s - p*theta;
    q    = td + sd;
    norm = p + q + r;

    % Random Variable Generation
    for i = 1:n

        while true
               
            U = rand(1); 
            V = rand(1); 
            W = rand(1);
            
            if U < (q / norm) % Uniform on [-sd, td]
                X = -sd + q*V; 
            elseif U < ((q + r) / norm) % Right tail 
                X = td - r*log(V); 
            else % Left tail
                X = -sd + p*log(V);
            end
    
            % Are we done?
            if X + m <= 0 % Enforce positive draw
                continue
            end
               
            if log(W) + logG(X, t, td, s, sd, eta, zeta, theta, xi) <= psiD(X, m, logmu, delta) 
                S(i) = X + m;
                break
            end
    
        end
    end
end

%% Auxiliary functions

function f = psiD(x, m, logmu, delta)
    f = delta*(logmu*x -gammaln(x+m) + gammaln(m));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = dpsiD(x, m, logmu, delta)
    f = delta*(logmu -psi(x+m));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = ddpsiD(x, m, delta)
    f = -delta*psi(1,x+m);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = logG(x, t, td, s, sd, eta, zeta, theta, xi)

    if((x >= -sd) && (x <= td))
        f = 0;
    elseif(x > td)
        f = -eta - zeta*(x-t);
    else
        f = -theta + xi*(x+s);   
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function t = findT(initval, m, logmu, delta)
    
    %Setup
    tol = 1e-2; 
    maxit = 40;

    %Initial Guess to the right of the mode (0)
    t = initval;
    
    %Halley’s Method
    for k = 1:maxit
        
        fy = psiD(t, m, logmu, delta) +1; %Evaluating whether to stop
        if all(abs(fy) < tol)
            break; 
        end

        dft   = dpsiD(t, m, logmu, delta);
        ddft  = ddpsiD(t, m, delta);
        inc   = (fy ./ dft)/(1 - 0.5*fy*ddft/dft^2);
        t     = t - inc;
            
    end

    if (k == maxit) && (abs(fy) >= tol || isnan(fy))
        warning("Halley’s Method has not converged."); 
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function s = findS(initval, m, logmu, delta)
    
    %Setup
    tol = 1e-2;
    maxit = 100;

    %Initial Guess to the left of the mode (0)
    s = initval;
    
    %Halley’s Method
    for k = 1:maxit
        
        fy = psiD(-s, m, logmu, delta)+1; %Evaluating whether to stop
        if all(abs(fy) < tol)
            break; 
        end

        dfs   = -dpsiD(-s, m, logmu, delta);
        ddfs  = ddpsiD(-s, m, delta);
        inc   = (fy ./ dfs)/(1 - 0.5*fy*ddfs/dfs^2);
        s     = s - inc;
            
    end

    if (k == maxit) && (abs(fy) >= tol || isnan(fy))
        warning("Halley’s Method has not converged."); 
    end

end
