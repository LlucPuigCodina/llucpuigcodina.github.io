function [S] = sampleGamConType1(logmu, delta, n)
% Sampling of the GamCon Type 1 distribution of Damsleth, E. Conjugate
% Classes for Gamma Distributions, Scand J Statist 2: 80-84, 1975.
%
% Implementation based on the algorithm of Devroye, L. Random variate
% generation for the generalized inverse Gaussian distribution. Stat Comput
% 24, 239-246, 2014.
%
% By Lluc Puig Codina

   %Preallocate
   S = NaN(n,1);

   % Mode
   m = invdigamma(logmu);

   % Initial guess based on local quadratic approximation psiD(x) ≈ -delta*psi(1,m)/2 * x^2.
   % Setting this equal to -1 gives x* ≈ sqrt(2/(delta*psi(1,m))), which scales correctly
   % with both delta and m.
   t0 = sqrt(2 / (delta * psi(1, m)));

   % Candidates t and s
    t = findT(t0, m, logmu, delta);
    s = findS(min(t0, 0.9*m), m, logmu, delta);
    
   % Algorithm with three piece hat
    % Calculate [-psi(t), -dpsi(t), -psi(-s), dpsi(-s)]
    eta      = -psiD(t, m, logmu, delta);
    zeta     = -dpsiD(t, m, logmu, delta);
    theta    = -psiD(-s, m, logmu, delta);
    xi       = dpsiD(-s, m, logmu, delta);

    % Compute p, r, td, sd and q
    pScale = 1./xi;
    r      = 1./zeta;
    td     = t - r*eta;
    sd     = s - pScale*theta;
    L      = max(-sd, -m);
    q      = td - L;

    if m > sd
        Vmin  = exp((-m+sd)/pScale);
        pMass = pScale*(1-Vmin);
    else
        Vmin = 1;   pMass = 0;
    end

    norm = pMass + q + r;

    % Random Variable Generation
    for i = 1:n

        while true

            U = rand(1);    V = rand(1);    W = rand(1);
            
            if U < (q / norm) % Uniform on [-sd, td]
                X = L + q*V; 
            elseif U < ((q + r) / norm) % Right tail 
                X = td - r*log(V); 
            else % Left tail
                Vt = Vmin + (1-Vmin)*V;
                X  = -sd + pScale*log(Vt);
            end
    
            % Are we done?
            if log(W) + logG(X, t, td, s, sd, eta, zeta, theta, xi) <= psiD(X, m, logmu, delta) 
                S(i) = X + m;
                break
            end
    
        end
    end
end

%% Auxiliary functions

function f = psiD(x, m, logmu, delta)
    f = delta*(logmu*x -gammaln(x+m) + gammaln(m));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = dpsiD(x, m, logmu, delta)
    f = delta*(logmu -psi(x+m));
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = ddpsiD(x, m, delta)
    f = -delta*psi(1,x+m);
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function f = logG(x, t, td, s, sd, eta, zeta, theta, xi)

    if((x >= -sd) && (x <= td))
        f = 0;
    elseif(x > td)
        f = -eta - zeta*(x-t);
    else
        f = -theta + xi*(x+s);   
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function t = findT(initval, m, logmu, delta)

    %Setup
    tol = 1e-2;
    maxit = 80;

    % The root lies in (0, Inf): g(t) = psiD(t) + 1 is monotone decreasing, with
    % g(0) = 1 > 0 and g(Inf) = -Inf < 0. Keep a bracket [tL, tU] (tU = Inf until
    % a sign change is found) and fall back to bisection / geometric expansion
    % when a Halley step leaves it, so t stays > 0 and gammaln(t + m) is defined.
    tL = 0;                      % g(tL) > 0
    tU = Inf;                    % g(tU) < 0  (not yet located)
    t  = max(initval, eps);      % start strictly to the right of the mode (0)

    %Halley's Method with bracket safeguard
    for k = 1:maxit

        fy = psiD(t, m, logmu, delta) + 1; %Evaluating whether to stop
        if abs(fy) < tol
            break;
        end

        if fy > 0, tL = t; else, tU = t; end    %Tighten bracket (g decreasing)

        dft  = dpsiD(t, m, logmu, delta);
        ddft = ddpsiD(t, m, delta);
        inc  = (fy ./ dft)/(1 - 0.5*fy*ddft/dft^2);
        tn   = t - inc;

        if ~isfinite(tn) || tn <= tL || tn >= tU %Step left the bracket
            if isfinite(tU)
                tn = 0.5*(tL + tU);              %  bisect
            else
                tn = 2*t + eps;                  %  no upper bound yet -> expand
            end
        end
        t = tn;

    end

    if (k == maxit) && (abs(fy) >= tol || isnan(fy))
        warning("Halley's Method has not converged.");
    end

end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function s = findS(initval, m, logmu, delta)

    %Setup
    tol = 1e-2;
    maxit = 80;

    % The root lies in (0, m): g(s) = psiD(-s) + 1 is monotone decreasing, with
    % g(0+) = 1 > 0 and g(m-) = -Inf < 0. Maintain a bracket [sL, sU] and fall
    % back to bisection whenever a Halley step would leave it, so that s stays
    % strictly inside (0, m) and z = m - s > 0 keeps gammaln(z) defined. Without
    % this, for small m (i.e. small mu) the first Halley step can overshoot
    % s >= m and gammaln of a non-positive argument errors.
    sL = 0;                                       % g(sL) > 0
    sU = m;                                       % g(sU) < 0  (endpoint never evaluated)
    s  = min(max(initval, eps), m*(1 - eps));     % start strictly inside (0, m)

    %Halley's Method with bisection safeguard
    for k = 1:maxit

        fy = psiD(-s, m, logmu, delta) + 1; %Evaluating whether to stop
        if abs(fy) < tol
            break;
        end

        if fy > 0, sL = s; else, sU = s; end    %Tighten bracket (g decreasing)

        dfs  = -dpsiD(-s, m, logmu, delta);
        ddfs =  ddpsiD(-s, m, delta);
        inc  = (fy ./ dfs)/(1 - 0.5*fy*ddfs/dfs^2);
        sn   = s - inc;

        if ~isfinite(sn) || sn <= sL || sn >= sU %Step left the bracket -> bisect
            sn = 0.5*(sL + sU);
        end
        s = sn;

    end

    if (k == maxit) && (abs(fy) >= tol || isnan(fy))
        warning("Halley's Method has not converged.");
    end

end
